import { LightningElement } from 'lwc';

export default class Lookupdemol extends LightningElement {}