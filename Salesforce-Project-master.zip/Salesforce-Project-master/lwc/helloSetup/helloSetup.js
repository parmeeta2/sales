import { LightningElement } from 'lwc';

export default class HelloSetup extends LightningElement {}